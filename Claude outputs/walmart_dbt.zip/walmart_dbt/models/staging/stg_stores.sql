-- Dedupes STORES_RAW down to one row per store_id, keeping whichever
-- load is most recent. This is where the "same rows can arrive in
-- multiple files" problem we discussed for Raw actually gets resolved -
-- Raw keeps every duplicate, Staging picks the winner.

with source as (
    select * from {{ source('raw', 'stores_raw') }}
),

deduped as (
    select
        store_id,
        store_type,
        store_size,
        _loaded_at,
        row_number() over (
            partition by store_id
            order by _loaded_at desc
        ) as rn
    from source
    where store_id is not null
)

select
    store_id,
    store_type,
    store_size,
    _loaded_at
from deduped
where rn = 1
